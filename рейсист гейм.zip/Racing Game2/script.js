const score = document.querySelector(".score");
const startScreen = document.querySelector(".startScreen");
const gameArea = document.querySelector(".game_zone");
startScreen.addEventListener("click", start);
let player = { speed: 5, score: 0 };
let playerReal = { speed: 5, score: 0 };
let keys = {
  ArrowUp: false,
  ArrowDown: false,
  ArrowLeft: false,
  ArrowRight: false,
};
let width_screen = document.querySelector(".carGame").style.width;
let benz_progress = document.getElementById("progressBenz");
let kolesa_progress = document.getElementById("progresskoles");
document.addEventListener("keydown", keyDown);
document.addEventListener("keyup", keyUp);
let music = new Audio();
music.src = "assets/music/soundtrack.WAV";

function keyDown(e) {
  e.preventDefault();
  keys[e.key] = true;
}

function keyUp(e) {
  e.preventDefault();
  keys[e.key] = false;
}

function isCollide(a, b) {
  aRect = a.getBoundingClientRect();
  bRect = b.getBoundingClientRect();
  return !(
    aRect.bottom < bRect.top ||
    aRect.top > bRect.bottom ||
    aRect.right < bRect.left ||
    aRect.left > bRect.right
  );
}

function moveLines() {
  let lines = document.querySelectorAll(".lines");
  lines.forEach(function (item) {
    if (item.y > 790) {
      item.y -= 740;
    }
    item.y += player.speed;
    item.style.top = item.y + "px";
  });
}

function endGame() {
  player.start = false;
  startScreen.classList.remove("hide");
  startScreen.innerHTML =
    "<h1>Игра окончена</h1> <br> Твои очки: " +
    player.score +
    " " +
    "<br>Нажми ещё раз, чтобы переиграть!";
}
let ogranichenie = false;
function moveZnak() {
  let znachok = document.querySelectorAll(".znak");
  znachok.forEach(function (item) {
    if (item.y >= 850) {
      item.y = Math.floor(Math.random() * -2000);
      ogranichenie = false;
    }
    if (item.y > -50) ogranichenie = true;
    if (item.y < -50) ogranichenie = false;
    item.y += player.speed * 0.5;
    item.style.top = item.y + "px";
  });
}
function moveEnemy(car) {
  let enemy = document.querySelectorAll(".enemy");
  enemy.forEach(function (item) {
    if (isCollide(car, item)) {
      console.log("Авария");
      endGame();
    }
    if (item.y >= 850) {
      item.y = -300;
      item.style.left = Math.floor(Math.random() * 180) + 180 + "px";
      randomBGEnemy(item);
    }
    item.y += player.speed;
    item.style.top = item.y + "px";
  });
}
function moveEnemyR(car) {
  let enemy = document.querySelectorAll(".enemyR");
  enemy.forEach(function (item) {
    if (isCollide(car, item)) {
      console.log("Авария");
      endGame();
    }
    if (item.y >= 850) {
      item.y = -300;
      item.style.left = Math.floor(Math.random() * 150) + "px";
      randomBGEnemyReverse(item);
    }
    if (ogranichenie) {
      item.y += player.speed * 0.9;
    } else {
      item.y += player.speed * 2;
    }

    item.style.top = item.y + "px";
  });
}
function moveBenzin(car) {
  let colonochka = document.querySelectorAll(".kanistra");
  colonochka.forEach(function (item) {
    if (isCollide(car, item)) {
      console.log("Заправка");
      if (benzin < 900) benzin += 100;
      item.y = -300;
      item.style.left = Math.floor(Math.random() * 350) + "px";
    }
    if (item.y >= 850) {
      item.y = -300;
      item.style.left = Math.floor(Math.random() * 350) + "px";
    }
    item.y += player.speed * 1.5;
    item.style.top = item.y + "px";
  });
}
function moveKoleso(car) {
  let kolesiki = document.querySelectorAll(".koleso_on_map");
  kolesiki.forEach(function (item) {
    if (isCollide(car, item)) {
      console.log("Перебортовка");
      kolesa += 250;
      item.y = -300;
      item.style.left = Math.floor(Math.random() * 350) + "px";
    }
    if (item.y >= 850) {
      item.y = -500;
      item.style.left = Math.floor(Math.random() * 350) + "px";
    }
    item.y += player.speed * 0.9;
    item.style.top = item.y + "px";
  });
}
let benzin = 1000;
benz_progress.setAttribute("max", benzin);
let kolesa = 1000;
kolesa_progress.setAttribute("max", kolesa);
function gamePlay() {
  benzin--;
  kolesa--;
  benz_progress.setAttribute("value", benzin);
  kolesa_progress.setAttribute("value", kolesa);
  if (benzin < 0) {
    endGame();
  }
  let car = document.querySelector(".car");
  let road = gameArea.getBoundingClientRect();
  if (kolesa > 750) playerReal.speed = 5;
  if (kolesa < 750 && kolesa > 500) playerReal.speed = 4;
  if (kolesa < 500 && kolesa > 300) playerReal.speed = 3;
  if (kolesa < 300 && kolesa > 200) playerReal.speed = 2;
  if (kolesa < 200 && kolesa > 100) playerReal.speed = 1;
  if (kolesa < 100) playerReal.speed = 0;
  if (player.start) {
    moveLines();
    moveEnemy(car);
    moveEnemyR(car);
    moveBenzin(car);
    moveKoleso(car);
    moveZnak();
    if (keys.ArrowUp && player.y > road.top + 70) {
      player.y -= playerReal.speed;
    }
    if (keys.ArrowDown && player.y < road.bottom - 85) {
      player.y += playerReal.speed;
    }
    if (keys.ArrowLeft && player.x > 0) {
      player.x -= playerReal.speed;
    }
    if (keys.ArrowRight && player.x < road.width - 50) {
      player.x += playerReal.speed;
    }
    car.style.top = player.y + "px";
    car.style.left = player.x + "px";
    window.requestAnimationFrame(gamePlay);
    player.score++;
    let ps = player.score - 1;
    score.innerText = "Score: " + ps;
  }
}
function start() {
  startScreen.classList.add("hide");
  gameArea.innerHTML = "";
  //music.play();
  player.start = true;
  player.score = 0;
  window.requestAnimationFrame(gamePlay);
  benzin = 1000;
  kolesa = 1000;
  benz_progress.setAttribute("value", benzin);
  kolesa_progress.setAttribute("value", kolesa);
  for (x = 0; x < 7; x++) {
    let roadLine = document.createElement("div");
    roadLine.setAttribute("class", "lines");
    roadLine.y = x * 150;
    roadLine.x = x * 300;
    roadLine.style.top = roadLine.y + "px";
    gameArea.appendChild(roadLine);
  }

  let car = document.createElement("div");
  car.setAttribute("class", "car");
  gameArea.appendChild(car);

  player.x = car.offsetLeft;
  player.y = car.offsetTop;

  for (x = 0; x < 3; x++) {
    let enemyCar = document.createElement("div");
    enemyCar.setAttribute("class", "enemy");
    enemyCar.y = (x + 1) * 350 * -1;
    enemyCar.style.top = enemyCar.y + "px";
    enemyCar.style.left = Math.floor(Math.random() * 180) + 180 + "px";
    randomBGEnemy(enemyCar);
    gameArea.appendChild(enemyCar);
  }
  for (x = 0; x < 3; x++) {
    let enemyCar = document.createElement("div");
    enemyCar.setAttribute("class", "enemyR");
    enemyCar.y = (x + 1) * 350 * -1;
    enemyCar.style.top = enemyCar.y + "px";
    enemyCar.style.left = Math.floor(Math.random() * 150) + "px";
    randomBGEnemyReverse(enemyCar);
    gameArea.appendChild(enemyCar);
  }
  for (x = 0; x < 3; x++) {
    let kanistra = document.createElement("div");
    kanistra.setAttribute("class", "kanistra");
    kanistra.y = (x + 1) * 350 * -1;
    kanistra.style.top = kanistra.y + "px";
    kanistra.style.left = Math.floor(Math.random() * 350) + "px";
    gameArea.appendChild(kanistra);
  }
  let koleso_on_map = document.createElement("div");
  koleso_on_map.setAttribute("class", "koleso_on_map");
  koleso_on_map.y = (x + 1) * 350 * -1;
  koleso_on_map.style.top = koleso_on_map.y + "px";
  koleso_on_map.style.left = Math.floor(Math.random() * 350) + "px";
  gameArea.appendChild(koleso_on_map);
  let znak_on_map = document.createElement("div");
  znak_on_map.setAttribute("class", "znak");
  znak_on_map.y = Math.floor(Math.random() * -1000);
  znak_on_map.style.top = znak_on_map.y + "px";
  znak_on_map.style.left = width_screen + "px";
  gameArea.appendChild(znak_on_map);
  ogranichenie = true;
}

function getRandomInt(max, step) {
  return Math.floor(Math.random() * max + step);
}

function randomBGEnemy(enemyCarForBG) {
  let randombg = getRandomInt(5, 0);
  if (randombg == 1) {
    enemyCarForBG.style.backgroundImage = "url(assets/img/1.png)";
  }
  if (randombg == 2) {
    enemyCarForBG.style.backgroundImage = "url(assets/img/2.png)";
  }
  if (randombg == 3) {
    enemyCarForBG.style.backgroundImage = "url(assets/img/3.png)";
  }
  if (randombg == 4) {
    enemyCarForBG.style.backgroundImage = "url(assets/img/4.png)";
  }
}

function randomBGEnemyReverse(enemyCarForBGR) {
  let randombg = getRandomInt(4, 1);
  if (randombg == 1) {
    enemyCarForBGR.style.backgroundImage = "url(assets/img/1r.png)";
  }
  if (randombg == 2) {
    enemyCarForBGR.style.backgroundImage = "url(assets/img/2r.png)";
  }
  if (randombg == 3) {
    enemyCarForBGR.style.backgroundImage = "url(assets/img/3r.png)";
  }
  if (randombg == 4) {
    enemyCarForBGR.style.backgroundImage = "url(assets/img/4r.png)";
  }
}
