const score = document.querySelector(".score");
const startScreen = document.querySelector(".startScreen");
const gameArea = document.querySelector(".game_zone");
startScreen.addEventListener("click", start);
let player = { speed: 5, score: 0 };
let playerReal = { speed: 5, score: 0 };
//массив для отслеживания нажатия кнопки и дальнейшего передвижения
let keys = {
  ArrowUp: false,
  ArrowDown: false,
  ArrowLeft: false,
  ArrowRight: false,
};
let width_screen = document.querySelector(".carGame").style.width;
let benz_progress = document.getElementById("progressBenz");
let kolesa_progress = document.getElementById("progresskoles");
document.addEventListener("keydown", keyDown);
document.addEventListener("keyup", keyUp);
//музыка при старте игры
let music = new Audio();
music.src = "assets/music/soundtrack.WAV";
//функция которая отслеживает нажата ли кнопка или нет и выбирает код при прослушивании с сайта с переходом в массив стрелок
function keyDown(e) {
  e.preventDefault();
  keys[e.key] = true;
}

//функция которая отслеживает отжата ли кнопка или нет и выбирает код при прослушивании с сайта с переходом в массив стрелок
function keyUp(e) {
  e.preventDefault();
  keys[e.key] = false;
}
//функция для проверки столкновения обьектов, берет два обьекта и проверяет их координаты относительно друг друга
function isCollide(a, b) {
  aRect = a.getBoundingClientRect();
  bRect = b.getBoundingClientRect();
  return !(
    aRect.bottom < bRect.top ||
    aRect.top > bRect.bottom ||
    aRect.right < bRect.left ||
    aRect.left > bRect.right
  );
}
//функция, которая находит все блоки с классом линии и двигает их, если линия вышла за пределы экрана то она перемещается вверх
function moveLines() {
  let lines = document.querySelectorAll(".lines");
  lines.forEach(function (item) {
    if (item.y > 790) {
      item.y -= 740;
    }
    item.y += player.speed;
    item.style.top = item.y + "px";
  });
}
//функция конца игры, обнуляет состояние активности и выводит меню для начала новой игры
function endGame() {
  player.start = false;
  startScreen.classList.remove("hide");
  startScreen.innerHTML =
    "<h1>Игра окончена</h1> <br> Твои очки: " +
    player.score +
    " " +
    "<br>Нажми ещё раз, чтобы переиграть!";
}
let ogranichenie = false;
/*передвигает дорожный знак в игре, если знак находится в области видимости, то машины встречки замедляются
 когда знак уходит из области видимости, то возвращает скорость машинам и случайно перемещается вверх
*/
function moveZnak() {
  let znachok = document.querySelectorAll(".znak");
  znachok.forEach(function (item) {
    if (item.y >= 850) {
      item.y = Math.floor(Math.random() * -2000);
      ogranichenie = false;
    }
    if (item.y > -50) ogranichenie = true;
    if (item.y < -50) ogranichenie = false;
    item.y += player.speed * 0.5;
    item.style.top = item.y + "px";
  });
}
/*двигает машину попутного направления, если наша машина сталкивается с этой то вызывается функция окончания игры 
если не сталкивается то перемещается вверх, меняя свое горизонтальное положение рандомно и меняет свой задний фон*/
function moveEnemy(car) {
  let enemy = document.querySelectorAll(".enemy");
  enemy.forEach(function (item) {
    if (isCollide(car, item)) {
      console.log("Авария");
      endGame();
    }
    if (item.y >= 850) {
      item.y = -300;
      item.style.left = Math.floor(Math.random() * 180) + 180 + "px";
      randomBGEnemy(item);
    }
    item.y += player.speed;
    item.style.top = item.y + "px";
  });
}
/*двигает машину встречного направления, если наша машина сталкивается с этой то вызывается функция окончания игры 
если не сталкивается то перемещается вверх, меняя свое горизонтальное положение рандомно и меняет свой задний фон*/
function moveEnemyR(car) {
  let enemy = document.querySelectorAll(".enemyR");
  enemy.forEach(function (item) {
    if (isCollide(car, item)) {
      console.log("Авария");
      endGame();
    }
    if (item.y >= 850) {
      item.y = -300;
      item.style.left = Math.floor(Math.random() * 150) + "px";
      randomBGEnemyReverse(item);
    }
    if (ogranichenie) {
      item.y += player.speed * 0.9;
    } else {
      item.y += player.speed * 2;
    }

    item.style.top = item.y + "px";
  });
}
/*двигает бензин по дороге, если мы с ним сталкиваемся, то он случайно меняет свое положение по горизонтали и двигается снова
если не сталкивается то перемещается вверх, меняя свое горизонтальное положение рандомно*/
function moveBenzin(car) {
  let colonochka = document.querySelectorAll(".kanistra");
  colonochka.forEach(function (item) {
    if (isCollide(car, item)) {
      console.log("Заправка");
      if (benzin < 900) benzin += 100;
      item.y = -300;
      item.style.left = Math.floor(Math.random() * 350) + "px";
    }
    if (item.y >= 850) {
      item.y = -300;
      item.style.left = Math.floor(Math.random() * 350) + "px";
    }
    item.y += player.speed * 1.5;
    item.style.top = item.y + "px";
  });
}
/*двигает колесо по дороге, если мы с ним сталкиваемся, то он случайно меняет свое положение по горизонтали и двигается снова
если не сталкивается то перемещается вверх, меняя свое горизонтальное положение рандомно*/
function moveKoleso(car) {
  let kolesiki = document.querySelectorAll(".koleso_on_map");
  kolesiki.forEach(function (item) {
    if (isCollide(car, item)) {
      console.log("Перебортовка");
      kolesa += 250;
      item.y = -300;
      item.style.left = Math.floor(Math.random() * 350) + "px";
    }
    if (item.y >= 850) {
      item.y = -500;
      item.style.left = Math.floor(Math.random() * 350) + "px";
    }
    item.y += player.speed * 0.9;
    item.style.top = item.y + "px";
  });
}
let benzin = 1000;
benz_progress.setAttribute("max", benzin);
let kolesa = 1000;
kolesa_progress.setAttribute("max", kolesa);
/*
самая главная функция, которая вызывает свое повторение с частотой экрана монитора с помощью requestAnimationFrame
подробнее о работе функции в коментах ниже
*/
function gamePlay() {
  //вычитаем со временем показатели износа колес и бензина и причисляем их к прогресс бару
  benzin--;
  kolesa--;
  benz_progress.setAttribute("value", benzin);
  kolesa_progress.setAttribute("value", kolesa);
  // если бензин закончился то конец игры
  if (benzin < 0) {
    endGame();
  }
  //находим нашу машину и определяем ее
  let car = document.querySelector(".car");
  //определяем размеры нашей дороги
  let road = gameArea.getBoundingClientRect();
  //меняем скорость нашей мащины в зависимости от износа колес
  if (kolesa > 750) playerReal.speed = 5;
  if (kolesa < 750 && kolesa > 500) playerReal.speed = 4;
  if (kolesa < 500 && kolesa > 300) playerReal.speed = 3;
  if (kolesa < 300 && kolesa > 200) playerReal.speed = 2;
  if (kolesa < 200 && kolesa > 100) playerReal.speed = 1;
  if (kolesa < 100) playerReal.speed = 0;
  //условие, срабатывающее если игрок активен
  if (player.start) {
    //вызываем все наши функции движения
    moveLines();
    moveEnemy(car);
    moveEnemyR(car);
    moveBenzin(car);
    moveKoleso(car);
    moveZnak();
    //если наши кнопки нажаты то мы двигаем нашу машинку в определенном направлении, вычитая или прибавляя переменную скорости
    if (keys.ArrowUp && player.y > road.top + 70) {
      player.y -= playerReal.speed;
    }
    if (keys.ArrowDown && player.y < road.bottom - 85) {
      player.y += playerReal.speed;
    }
    if (keys.ArrowLeft && player.x > 0) {
      player.x -= playerReal.speed;
    }
    if (keys.ArrowRight && player.x < road.width - 50) {
      player.x += playerReal.speed;
    }
    car.style.top = player.y + "px";
    car.style.left = player.x + "px";
    //запрашиваем повторное выполнение нашей функции
    window.requestAnimationFrame(gamePlay);
    //прибавляем очки игрока
    player.score++;
    let ps = player.score - 1;
    score.innerText = "Score: " + ps;
  }
}
//функция старта игры, которая вызывается при нажатии на поле старта, далее о функции в коментах ниже
function start() {
  //прячем поле старта игры
  startScreen.classList.add("hide");
  gameArea.innerHTML = "";
  //запускаем музыку
  music.play();
  //задаем значение активности игрока на тру
  player.start = true;
  //обнуляем очки игрока
  player.score = 0;
  //вызываем нашу функцию игры
  window.requestAnimationFrame(gamePlay);
  //обновляем показатели бензина и колес
  benzin = 1000;
  kolesa = 1000;
  benz_progress.setAttribute("value", benzin);
  kolesa_progress.setAttribute("value", kolesa);
  //создаем семь блоков с классом линия и добавляем их в нашу игровую зону
  for (x = 0; x < 7; x++) {
    let roadLine = document.createElement("div");
    roadLine.setAttribute("class", "lines");
    roadLine.y = x * 150;
    roadLine.x = x * 300;
    roadLine.style.top = roadLine.y + "px";
    gameArea.appendChild(roadLine);
  }
  //создаем нашу машинку и добавляем в зону
  let car = document.createElement("div");
  car.setAttribute("class", "car");
  gameArea.appendChild(car);
  player.x = car.offsetLeft;
  player.y = car.offsetTop;
  //создаем 3 машины попутного направления, случайно задавая им задний фон и положение
  for (x = 0; x < 3; x++) {
    let enemyCar = document.createElement("div");
    enemyCar.setAttribute("class", "enemy");
    enemyCar.y = (x + 1) * 350 * -1;
    enemyCar.style.top = enemyCar.y + "px";
    enemyCar.style.left = Math.floor(Math.random() * 180) + 180 + "px";
    randomBGEnemy(enemyCar);
    gameArea.appendChild(enemyCar);
  }
  //создаем 3 машины встречного направления, случайно задавая им задний фон и положение
  for (x = 0; x < 3; x++) {
    let enemyCar = document.createElement("div");
    enemyCar.setAttribute("class", "enemyR");
    enemyCar.y = (x + 1) * 350 * -1;
    enemyCar.style.top = enemyCar.y + "px";
    enemyCar.style.left = Math.floor(Math.random() * 150) + "px";
    randomBGEnemyReverse(enemyCar);
    gameArea.appendChild(enemyCar);
  }
  //создаем 3 канистры бензина, случайно задавая им положение
  for (x = 0; x < 3; x++) {
    let kanistra = document.createElement("div");
    kanistra.setAttribute("class", "kanistra");
    kanistra.y = (x + 1) * 350 * -1;
    kanistra.style.top = kanistra.y + "px";
    kanistra.style.left = Math.floor(Math.random() * 350) + "px";
    gameArea.appendChild(kanistra);
  }
  //создаем колесо и добавляем в игровую зону, случайно задавая ему положение
  let koleso_on_map = document.createElement("div");
  koleso_on_map.setAttribute("class", "koleso_on_map");
  koleso_on_map.y = (x + 1) * 350 * -1;
  koleso_on_map.style.top = koleso_on_map.y + "px";
  koleso_on_map.style.left = Math.floor(Math.random() * 350) + "px";
  gameArea.appendChild(koleso_on_map);

  //создаем знак и добавляем в зону
  let znak_on_map = document.createElement("div");
  znak_on_map.setAttribute("class", "znak");
  znak_on_map.y = Math.floor(Math.random() * -1000);
  znak_on_map.style.top = znak_on_map.y + "px";
  znak_on_map.style.left = width_screen + "px";
  gameArea.appendChild(znak_on_map);
  ogranichenie = true;
}
//функция для нахождения случайного целочисленного значения с верхней и нижней границей
function getRandomInt(max, step) {
  return Math.floor(Math.random() * max + step);
}

//функция случайного заднего фона для машин попутного направления
function randomBGEnemy(enemyCarForBG) {
  let randombg = getRandomInt(5, 0);
  if (randombg == 1) {
    enemyCarForBG.style.backgroundImage = "url(assets/img/1.png)";
  }
  if (randombg == 2) {
    enemyCarForBG.style.backgroundImage = "url(assets/img/2.png)";
  }
  if (randombg == 3) {
    enemyCarForBG.style.backgroundImage = "url(assets/img/3.png)";
  }
  if (randombg == 4) {
    enemyCarForBG.style.backgroundImage = "url(assets/img/4.png)";
  }
}
//функция случайного заднего фона для машин встречного направления направления
function randomBGEnemyReverse(enemyCarForBGR) {
  let randombg = getRandomInt(4, 1);
  if (randombg == 1) {
    enemyCarForBGR.style.backgroundImage = "url(assets/img/1r.png)";
  }
  if (randombg == 2) {
    enemyCarForBGR.style.backgroundImage = "url(assets/img/2r.png)";
  }
  if (randombg == 3) {
    enemyCarForBGR.style.backgroundImage = "url(assets/img/3r.png)";
  }
  if (randombg == 4) {
    enemyCarForBGR.style.backgroundImage = "url(assets/img/4r.png)";
  }
}
